from django.apps import AppConfig


class AlzcareappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'AlzCareApp'
