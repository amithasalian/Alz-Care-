from django.shortcuts import render
from rest_framework.parsers import MultiPartParser, FormParser
from rest_framework.views import APIView
from rest_framework.generics import GenericAPIView
from rest_framework.response import Response
from django.contrib.auth.hashers import check_password
import random
from django.utils import timezone
from datetime import timedelta
from django.db import transaction
import random
import base64

from .models import *
from .core.serializers import *
from .core.apiResponse import ApiResponse
from .core.utils import send_push_notification, send_password_reset_email, deleteImage
from .core.exceptions import ValidationException, ApiException

# Create your views here.

def getUserByEmail(email):
    user = User.objects.filter(email=email).first()
    if not user:
        raise ApiException("Invalid email address.")
    return user

class AuthView(APIView):
    def post(self, request, *args, **kwargs):
        action = kwargs.get("action")

        if action == "register":
            return self.register(request)
        elif action == "login":
            return self.login(request)
        elif action == "send-otp":
            return self.sendOtp(request)
        elif action == "verify-otp":
            return self.verifyOtp(request)
        else:
            return ApiResponse.error("Invalid action")

    def register(self, request):
        serializer = UserSerializer(data=request.data)
        if serializer.is_valid():
            user = serializer.save()
            return  ApiResponse.success("User registered successfully",{
                "id": user.id,
                "name": user.name,
                "email": user.email,
                "contact": user.contact
            })
        raise ValidationException(serializer.errors)

    def login(self, request): 
        email = request.data.get('email')
        password = request.data.get('password')
        token = request.data.get('token')
        deviceId = request.data.get('deviceId')
        
        if not email or not password:
            return ApiResponse.error("Both email and password are required")
    
        user = getUserByEmail(email)
    
        if not check_password(password, user.password):
            return ApiResponse.error("Invalid credentials")
        
        if user.user_type != UserType.USER:
            return ApiResponse.error("Invalid credentials")

        FcmToken.objects.update_or_create(
            user = user,
            device_id = deviceId,
            defaults={'fcm_token': token}
        )
        # Send login notification with welcome message
        send_push_notification(token=token, title="Welcome Back!", body=f"Hi {user.name}, you have successfully logged in to AlzCare +.")
        return ApiResponse.success("Login successful", {
            "id": user.id,
            "name": user.name,
            "email": user.email,
            "contact": user.contact
        })
    
    def sendOtp(self, request): 
        email = request.data.get("email")
        if not email:
            return ApiResponse.error("Email is required")
        
        user = getUserByEmail(email)
        
        otp_code = random.randint(100000, 999999)
        User.objects.filter(id= user.id).update(
            otp_value= otp_code,
            otp_created_at=timezone.now()
        )
        print("otp value :",otp_code)
        send_password_reset_email(email, otp_code, user.name)
        return ApiResponse.success("OTP sent successfully. Check your email.",email)
    
    def verifyOtp(self, request):
        email = request.data.get("email")
        otp = request.data.get("otp")
        new_password = request.data.get("password")

        if not email or not otp or not new_password:
            return ApiResponse.error("Email,OTP and password are required.")
        
        user = getUserByEmail(email)
        
        # Check if OTP exists and is valid
        if not user.otp_value or str(user.otp_value) != str(otp):
            return ApiResponse.error("Incorrect OTP. Please try again.")
        
        # Check OTP expiration (assuming 10 minutes validity)
        if timezone.now() > user.otp_created_at + timedelta(minutes=10):
            return ApiResponse.error("OTP has expired. Please request a new one.")

        # OTP is valid, reset it in the database
        user.password = make_password(new_password)
        user.otp_value = None
        user.otp_created_at = None
        user.save()

        return ApiResponse.success("Password reset successfully. You can now log in.")


class UserProfileView(GenericAPIView):
    serializer_class = UserSerializer
    parser_classes = [MultiPartParser, FormParser]

    def get(self, request, *args, **kwargs):
        user_id = request.query_params.get('user')

        if not user_id:
            return ApiResponse.error("User ID is required")
        
        user = User.objects.filter(id= user_id).first()

        if not user:
           return ApiResponse.error("User not found")

        user_serializer = self.get_serializer(user, context={"request": request})
        return ApiResponse.success("User retrieved successfully", user_serializer.data)
    
    def post(self, request):
        userId = request.data.get("user")
        if not userId:
            return ApiResponse.error("Invalid user..")
        
        try:
            user = User.objects.get(pk=userId)
        except User.DoesNotExist:
            return ApiResponse.error("Invalid user")
        user_serializer = self.get_serializer(user, data= request.data, partial= True, context={"request": request})
        if user_serializer.is_valid():
            user_serializer.save()
            # if user.image:
            #     deleteImage(user.image)
            return ApiResponse.success("User updated successfully", user_serializer.data)
        else:   
            raise ValidationException(user_serializer.errors)   
        

class MedicineReminderView(GenericAPIView):
    serializer_class = ReminderSerializer

    def get(self, request):
        user_id= request.GET['user']

        user= User.objects.filter(id=user_id).first()
        if not user:
            return ApiResponse.error("Invalid user...")
        
        reminders = Remainder.objects.filter(user=user).order_by('-id')
        reminder_serializer = self.get_serializer(reminders, many=True, context={"request": request})
        return ApiResponse.success("Reminders retrieved successfully.", reminder_serializer.data)

    @transaction.atomic
    def post(self, request):
        reminder_serial = self.get_serializer(data=request.data, context={"request": request})

        if reminder_serial.is_valid():
            reminder = reminder_serial.save()

            times = request.data.get('times')
            if not times:
                raise ValidationException({"times": ["This field is required."]})

            try:
                for remind_time in times:
                    ReminderTimes.objects.create(
                        reminder=reminder,
                        user=reminder.user,
                        time=remind_time
                    )
            except Exception as e:
                raise ValidationException({"reminder_times": [str(e)]})
            
            print(reminder_serial.data)
            return ApiResponse.success("Reminder added successfully.", reminder_serial.data)
        else:
            raise ValidationException(reminder_serial.errors)
        
    def delete(self, request):
        reminder_id = request.GET.get('reminder') 

        if not reminder_id:
            return ApiResponse.error("Reminder ID is required.")

        reminder = Remainder.objects.filter(id=reminder_id).first()

        if not reminder:
            return ApiResponse.error("Reminder not found.")
        
        reminder.delete()

        return ApiResponse.success("Reminder deleted successfully.")

    
                    
class PredictDiseaseView(GenericAPIView):
    def post(self, request):
        uploaded_file = request.FILES.get('image')
        user = request.data.get('user')

        with open('Media/uploads/image.png', 'wb') as f:
            for chunk in uploaded_file.chunks():
                f.write(chunk)

        return ApiResponse.success("Predicted result")        