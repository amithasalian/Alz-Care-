from django.contrib.auth.hashers import make_password
from rest_framework import serializers
from AlzCareApp.models import User, Remainder, ReminderTimes, Notifications


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'name', 'contact', 'email', 'password', 'image']
        extra_kwargs = {'password': {'write_only': True}}
    
    def create(self, validated_data):
        """Hash password before saving"""
        validated_data['password'] = make_password(validated_data['password'])
        return super().create(validated_data)   


class ReminderTimeSerializer(serializers.ModelSerializer):
    class Meta:
        model = ReminderTimes
        fields = ['id', 'reminder', 'user', 'time']


class ReminderSerializer(serializers.ModelSerializer):
    reminder_time = ReminderTimeSerializer(many=True, read_only=True)
    
    class Meta:
        model = Remainder
        fields = ['id', 'user', 'title', 'description', 'from_date', 'to_date', 'reminder_time']
        extra_kwargs = {
            'from_date': {'input_formats': ['%d-%m-%Y']},
            'to_date': {'input_formats': ['%d-%m-%Y']}
        }