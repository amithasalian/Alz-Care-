from typing import Optional
from rest_framework.response import Response
from rest_framework import status

class ApiResponse:
    @staticmethod
    def success(message: str, data: Optional[dict] = None):
        """Creates a success API response format."""
        return Response({
            "status": True,
            "message": message,
            "data": data if data is not None else {}
        }, status=status.HTTP_200_OK)

    @staticmethod
    def error(message: str, data: Optional[dict] = None):
        """Creates an error API response format."""
        return Response({
            "status": False,
            "message": message,
            "data": data if data is not None else {}
        }, status=status.HTTP_400_BAD_REQUEST)

   
