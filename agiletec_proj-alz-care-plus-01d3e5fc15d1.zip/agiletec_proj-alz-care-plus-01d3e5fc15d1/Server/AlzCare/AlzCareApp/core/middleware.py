import json
from django.utils.deprecation import MiddlewareMixin
from django.http import JsonResponse
import json
import traceback
from .apiResponse import ApiResponse
from .exceptions import ValidationException,ApiException

class RequestLoggingMiddleware(MiddlewareMixin):
    def process_request(self, request):
        print("\n===== Incoming Request =====")
        print(f"Method: {request.method}")
        print(f"Path: {request.path}")

        # Print GET parameters
        if request.GET:
            print(f"GET Params: {dict(request.GET)}")

        # Print POST, PUT, PATCH data
        if request.method in ['POST', 'PUT', 'PATCH']:
            if request.content_type == "application/json":
                try:
                    body = json.loads(request.body.decode('utf-8'))
                    print(f"Data (JSON): {body}")
                except json.JSONDecodeError:
                    print("Data: Cannot decode JSON")
            else:
                print(f"Data (Form): {dict(request.POST)}")

        # Print files if any
        if request.FILES:
            print(f"Uploaded Files: {[file.name for file in request.FILES.values()]}")

        print("============================\n")


class GlobalExceptionMiddleware(MiddlewareMixin):
    def process_exception(self, request, exception):
        """Catches all exceptions globally and returns a JSON response."""

        if isinstance(exception, ValidationException):
            return JsonResponse({ 
                "status":False,
                "message": str(exception)},
                status=400  # Return a 400 Bad Request for validation errors
            )
        
        if isinstance(exception, ApiException):
            return JsonResponse({ 
                "status":False,
                "message": str(exception)},
                status=exception.status_code
            )

        # Log the traceback for debugging
        print("Unhandled Exception:", exception)
        print(traceback.format_exc())

        # Return a generic error response for other exceptions
        return JsonResponse(
            { "status":False,"message": "An unexpected error occurred."},
            status=500
        )
