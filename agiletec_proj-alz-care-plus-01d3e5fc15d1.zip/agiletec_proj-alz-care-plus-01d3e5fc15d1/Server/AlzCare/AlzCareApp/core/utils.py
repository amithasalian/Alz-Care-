import firebase_admin
from firebase_admin import messaging
from django.core.mail import send_mail
import os
from django.conf import settings
import secrets
import string
import json

def app_constants(request):
    return {
        'APP_NAME': 'Crime Report',
    }

def deleteImage(filename):
    image_path = os.path.join(settings.MEDIA_ROOT, str(filename))
    if os.path.exists(image_path):
        os.remove(image_path)
        print(f'File removed successfully : {image_path}')    
    print(f'File not found : {image_path}')    

# to send a firebase push notifications
def send_push_notification(token, title, body, data=None):
    message = messaging.Message(
        notification=messaging.Notification(
                title=title,
                body=body,
        ),
        token=token,
        data=data if data else {}
        )
    return messaging.send(message)

def send_password_reset_email(user_email, otp_code, user_first_name):
    subject = "🔐 AlzCare + – Password Reset OTP"
    message = f"""
Dear {user_first_name},

We received a request to reset your password for your AlzCare + Application account.

Your One-Time Password (OTP) for resetting your password is:

🔢 {otp_code}

This OTP is valid for the next 10 minutes. Please do not share it with anyone.

If you did not request this, please ignore this email. Your account remains secure.

Best regards,
AlzCare Support Team
support@alzcare.com
"""
    send_mail(subject, message, "no-reply@alzcare.com", [user_email])