class ValidationException(Exception):
    """Custom exception for validation errors."""
    def __init__(self, errors):
        self.message = self.extract_message(errors)
        super().__init__(self.message)  # Ensure the message is properly set
    
    @staticmethod
    def extract_message(errors):
        """Extracts the first error message from serializer errors."""
        print(errors)
        if isinstance(errors, dict):
            for field, messages in errors.items():
                if isinstance(messages, list) and messages:
                    return f"{messages[0]}"
                elif isinstance(messages, str):
                    return f"{messages}"
        return "Validation error occurred."

class ApiException(Exception):
    """Custom exception for API errors."""
    
    def __init__(self, message, status_code=400):
        super().__init__(message)
        self.message = message
        self.status_code = status_code

    
