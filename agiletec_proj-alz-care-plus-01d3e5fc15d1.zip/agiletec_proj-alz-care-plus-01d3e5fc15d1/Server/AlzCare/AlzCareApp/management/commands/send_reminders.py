# myapp/management/commands/send_reminders.py
from django.core.management.base import BaseCommand
from AlzCareApp.models import User, Remainder, ReminderTimes, FcmToken
from AlzCareApp.core.utils import send_push_notification
from datetime import datetime, timedelta
from django.db.models import Q
import time

# ANSI escape codes for color formatting
GREEN = '\033[92m'
RESET = '\033[0m'

def success(message):
    print(f"{GREEN}{message}{RESET}")

RED = '\033[91m'

def error(message):
    print(f"{RED}{message}{RESET}")    

def send_remainder_notification(user_id, message_title,message_body):
    user = User.objects.get(pk=user_id)
    fcm = FcmToken.objects.filter(user= user).first()
    send_push_notification(fcm.fcm_token, message_title, message_body)
    success(f"Push notification sent to {user.name}")


class Command(BaseCommand):
    help = 'Check and send reminders'

    def handle(self, *args, **options):
        success(f"Started to check reminders")

        while True:
            current_datetime = datetime.now()
            fifteen_mins_later = current_datetime + timedelta(minutes=15)
            fifteen_mins_later = fifteen_mins_later.replace(second=0, microsecond=000000)

            results = Remainder.objects.filter(
                (Q(from_date=current_datetime.date()) | Q(to_date=current_datetime.date()) |
                 (Q(from_date__lte=current_datetime.date()) & Q(to_date__gte=current_datetime.date()))),
            )

            if results.exists():
                for reminder in results:
                    for reminder_time in ReminderTimes.objects.filter(reminder=reminder,time=fifteen_mins_later.time()):
                        am_pm_format = reminder_time.time.strftime("%I:%M %p")

                        message_body = f"Don't forget to take your {reminder.title} at {am_pm_format}. This is a reminder 15 mins in advance."
                        send_remainder_notification(reminder.user.id, "Medicine Reminder",message_body)
            
            time.sleep(60) 
