from django.db import models
import os
import uuid


def unique_filename(instance, filename, folder):
    """Generates a unique filename in the specified folder."""
    ext = filename.split('.')[-1]
    unique_filename = f"{uuid.uuid4()}.{ext}"
    return os.path.join(f'uploads/{folder}/', unique_filename)

def unique_user_image_filename(instance, filename):
    return unique_filename(instance, filename, "users")

class UserType(models.TextChoices):
    USER = 'User', 'User'
    ADMIN = 'Admin', 'Admin'

# Create your models here.

# To manage registered user records
class User(models.Model):
    class Meta:
        db_table = 'users'
        
    user_type = models.CharField(max_length=6, choices=UserType.choices, default=UserType.USER)
    name = models.CharField(blank=False, max_length=50)
    contact = models.CharField(blank=False, max_length=50, unique=True)
    email = models.EmailField(blank=False, max_length=100, unique=True) 
    password = models.CharField(max_length=120)
    image = models.ImageField(null=True, default=None, upload_to=unique_user_image_filename)
    otp_value = models.IntegerField(blank=True,null=True, default=None)
    otp_created_at = models.DateTimeField(null=True, blank=True)  # Stores OTP timestamp
    is_active = models.IntegerField(default=1)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

# To keep the firebase cloud messaging tokens
class FcmToken(models.Model):
    class Meta:
        db_table = 'fcm_token' 
        unique_together = ('user', 'device_id') 

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='fcm_user') 
    fcm_token = models.TextField(blank=False)
    device_id = models.CharField(max_length=100, blank=False, unique=True)
    created_at = models.DateTimeField(auto_now_add=True)

#  To keep the medicine reminder data 
class Remainder(models.Model):
    class Meta:
        db_table = 'remainder'

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="reminder_user")
    title = models.TextField(default=None)  
    description = models.TextField(default=None)  
    from_date = models.DateField()
    to_date = models.DateField()
    is_active = models.IntegerField(default = 1)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)


class ReminderTimes(models.Model):
    class Meta:
        db_table = 'reminder_time'
    
    reminder = models.ForeignKey(Remainder, on_delete=models.CASCADE, related_name="reminder_time")
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="user_times")
    time = models.TimeField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)


class Notifications(models.Model):
    class Meta:
        db_table = 'notifications'

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="notify_user")
    notify_type = models.CharField(max_length=10, blank=False, default=None)
    notify_title = models.CharField(max_length=100, blank=False, default=None)
    notify_description = models.TextField(blank=False, default=None)
    created_at = models.DateTimeField(auto_now_add=True)


    