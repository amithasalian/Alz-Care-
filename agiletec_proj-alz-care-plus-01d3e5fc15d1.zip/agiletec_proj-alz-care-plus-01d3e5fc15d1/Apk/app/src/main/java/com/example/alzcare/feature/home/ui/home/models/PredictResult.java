package com.example.alzcare.feature.home.ui.home.models;

public class PredictResult {
}
