package com.example.alzcare.network.handlers;

public interface ResponseListener<T> {
    void onSuccess(T response);

    void onFailure(String errorMessage);
}
