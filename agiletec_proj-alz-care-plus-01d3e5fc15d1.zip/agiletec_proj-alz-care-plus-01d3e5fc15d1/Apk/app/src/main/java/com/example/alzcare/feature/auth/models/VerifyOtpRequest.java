package com.example.alzcare.feature.auth.models;

public class VerifyOtpRequest {
    private final String email, otp, password;

    public VerifyOtpRequest(String email, String otp,String password) {
        this.email = email;
        this.otp = otp;
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public String getOtp() {
        return otp;
    }

    public String getPassword() {
        return password;
    }
}
