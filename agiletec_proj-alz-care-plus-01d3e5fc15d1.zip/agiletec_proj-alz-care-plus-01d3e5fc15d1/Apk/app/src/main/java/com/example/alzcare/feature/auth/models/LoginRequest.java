package com.example.alzcare.feature.auth.models;

public class LoginRequest {
    private final String email, password, token, deviceId;

    public LoginRequest(String email, String password, String token, String deviceId) {
        this.email = email;
        this.password = password;
        this.token = token;
        this.deviceId = deviceId;
    }

    public String getToken() {
        return token;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }
}
