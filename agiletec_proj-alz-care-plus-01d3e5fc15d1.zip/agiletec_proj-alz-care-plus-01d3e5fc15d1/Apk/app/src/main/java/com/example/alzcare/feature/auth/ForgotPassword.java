package com.example.alzcare.feature.auth;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.alzcare.R;
import com.example.alzcare.common.models.ApiResponse;
import com.example.alzcare.common.utils.UiHandlers;
import com.example.alzcare.feature.auth.models.SendOtpRequest;
import com.example.alzcare.feature.auth.models.VerifyOtpRequest;
import com.example.alzcare.network.handlers.RequestHandler;
import com.example.alzcare.network.handlers.ResponseListener;
import com.google.android.material.textfield.TextInputLayout;

public class ForgotPassword extends AppCompatActivity {
    private Toolbar toolbar;
    private EditText emailOtpText, otpValue, newPassword, ConfirmPassword;
    private TextView headerText;
    private Button submitButton;
    private ProgressBar progressBar;
    private RequestHandler requestHandler;
    private TextInputLayout emailLayout;
    private boolean isOtpConfirm = false;
    private LinearLayout passwordChangeLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_forgot_password);
        requestHandler = new RequestHandler();

        emailOtpText = findViewById(R.id.forgot_email);
        otpValue = findViewById(R.id.otp_value);
        headerText = findViewById(R.id.headerText);
        submitButton = findViewById(R.id.submit_button);
        progressBar = findViewById(R.id.progressBar);
        emailLayout = findViewById(R.id.emailLayout);
        newPassword = findViewById(R.id.new_password);
        ConfirmPassword = findViewById(R.id.confirm_password);
        passwordChangeLayout = findViewById(R.id.passwordChangeLayout);

        toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Forgot password");
        toolbar.setNavigationOnClickListener(v -> finish());

        submitButton.setOnClickListener(view -> {
            if (isOtpConfirm) {
                if (newPassword.length() == 0) {
                    UiHandlers.shortToast(this, "Please enter new password");
                    return;
                }
                if (ConfirmPassword.length() == 0) {
                    UiHandlers.shortToast(this, "Please enter confirm password");
                    return;
                }
                if (!newPassword.getText().toString().equals(ConfirmPassword.getText().toString())) {
                    UiHandlers.shortToast(this, "Password not matched");
                    return;
                }
                if (otpValue.length() == 0) {
                    UiHandlers.shortToast(this, "Please enter valid 6 digit otp..");
                    return;
                }
                verifyOtp(new VerifyOtpRequest(
                        emailOtpText.getText().toString(),
                        otpValue.getText().toString(),
                        newPassword.getText().toString()
                ));
                return;
            }
            if (emailOtpText.length() == 0) {
                UiHandlers.shortToast(this, "Please enter email");
                return;
            }
            UiHandlers.showProgress(progressBar, submitButton);
            sendOtp(emailOtpText.getText().toString());
        });
    }
    private void sendOtp(String email) {
        SendOtpRequest sendOtpRequest = new SendOtpRequest(email);
        requestHandler.sendOtp(sendOtpRequest, new ResponseListener<ApiResponse<String>>() {
            @Override
            public void onSuccess(ApiResponse<String> response) {
                UiHandlers.hideProgress(progressBar, submitButton);
                UiHandlers.shortToast(getApplicationContext(), response.getMessage());
                if (response.isSuccess()) {
                    makeEnterOtp(response.getData());
                }
            }

            @Override
            public void onFailure(String errorMessage) {
                UiHandlers.hideProgress(progressBar, submitButton);
                UiHandlers.shortToast(getApplicationContext(), errorMessage);
            }
        });
    }

    private void verifyOtp(VerifyOtpRequest verifyOtpRequest) {
        requestHandler.verifyOtp(verifyOtpRequest, new ResponseListener<ApiResponse<Void>>() {
            @Override
            public void onSuccess(ApiResponse<Void> response) {
                UiHandlers.hideProgress(progressBar, submitButton);
                UiHandlers.shortToast(getApplicationContext(), response.getMessage());
                if (response.isSuccess()) {
                    Intent intent = new Intent(ForgotPassword.this, LoginActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                }
            }

            @Override
            public void onFailure(String errorMessage) {
                UiHandlers.hideProgress(progressBar, submitButton);
                UiHandlers.shortToast(getApplicationContext(), errorMessage);
            }
        });
    }


    @SuppressLint("SetTextI18n")
    private void makeEnterOtp(String email) {
        emailLayout.setVisibility(View.GONE);
        passwordChangeLayout.setVisibility(View.VISIBLE);

        submitButton.setText("Confirm Otp and Password");
        toolbar.setTitle("Forgot Password");
        headerText.setText("Enter the otp sent to your email address :" + email);
        isOtpConfirm = true;
    }
}