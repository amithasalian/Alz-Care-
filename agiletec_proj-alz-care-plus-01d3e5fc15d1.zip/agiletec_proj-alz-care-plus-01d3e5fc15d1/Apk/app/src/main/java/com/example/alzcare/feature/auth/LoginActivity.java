package com.example.alzcare.feature.auth;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.example.alzcare.R;
import com.example.alzcare.common.models.ApiResponse;
import com.example.alzcare.common.models.UserSession;
import com.example.alzcare.common.utils.SharedPref;
import com.example.alzcare.common.utils.UiHandlers;
import com.example.alzcare.common.utils.Utils;
import com.example.alzcare.feature.auth.models.LoginRequest;
import com.example.alzcare.feature.home.HomeActivity;
import com.example.alzcare.network.handlers.RequestHandler;
import com.example.alzcare.network.handlers.ResponseListener;
import com.google.firebase.messaging.FirebaseMessaging;

public class LoginActivity extends AppCompatActivity {
    private Button Login, forgotPassword;
    private EditText Email, Password;
    private ProgressBar progressBar;
    private RequestHandler requestHandler;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);

        requestHandler = new RequestHandler();
        Email = findViewById(R.id.login_email);
        Password = findViewById(R.id.login_password);
        forgotPassword = findViewById(R.id.userForgot);
        Login = findViewById(R.id.login_submit);
        Button signUp = findViewById(R.id.userSignUp);
        progressBar = findViewById(R.id.progressBar);

        signUp.setOnClickListener(v -> {
            startActivity(new Intent(this, RegisterActivity.class));
        });

        forgotPassword.setOnClickListener(view -> {
            startActivity(new Intent(this, ForgotPassword.class));
        });

        Login.setOnClickListener(view -> {
            if (isValidated()) {
                FirebaseMessaging.getInstance().getToken().addOnCompleteListener(command -> {
                    if (!command.isSuccessful()) {
                        System.out.println("Fetching FCM registration token failed");
                        return;
                    }
                    String token = command.getResult();
                    loginUser(token);
                });
            }
        });
    }

    private void loginUser(String token) {
        String deviceId = Utils.getDeviceId(getApplicationContext());
        LoginRequest request = new LoginRequest(
                Email.getText().toString(),
                Password.getText().toString(),
                token, deviceId
        );
        UiHandlers.showProgress(progressBar, Login);

        requestHandler.loginUser(request, new ResponseListener<ApiResponse<UserSession>>() {
            @Override
            public void onSuccess(ApiResponse<UserSession> response) {
                UiHandlers.hideProgress(progressBar, Login);
                if (response.isSuccess()) {
                    UiHandlers.shortToast(getApplicationContext(), "Login Successful..");
                    SharedPref.setIsAuthenticated(getApplicationContext(), true);
                    SharedPref.saveUserSession(getApplicationContext(), response.getData());
                    Intent intent = new Intent(LoginActivity.this, HomeActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    return;
                }
                UiHandlers.shortToast(getApplicationContext(), response.getMessage());
            }

            @Override
            public void onFailure(String errorMessage) {
                UiHandlers.hideProgress(progressBar, Login);
                UiHandlers.shortToast(getApplicationContext(), errorMessage);
            }
        });
    }

    private boolean isValidated() {
        if (Email.length() == 0) {
            UiHandlers.shortToast(getApplicationContext(), "Email id is required");
            return false;
        }
        if (Password.length() == 0) {
            UiHandlers.shortToast(getApplicationContext(), "Password is required");
            return false;
        }
        return true;
    }
}