package com.example.alzcare.constants;

public interface AppConstants {
    String IP = "192.168.1.2";
    String ROOT_URL = "http:" + IP + ":8000";
    int REQUEST_CODE_PERMISSIONS = 100;

}
