package com.example.alzcare.feature.home.ui.user.models;

import com.google.gson.annotations.SerializedName;

public class UserModel {
    @SerializedName("id")
    private String userId;

    @SerializedName("name")
    private String userName;

    @SerializedName("email")
    private String userEmail;

    @SerializedName("contact")
    private String userContact;

    @SerializedName("image")
    private String userImage;

    public String getUserId() {
        return userId;
    }

    public String getUserName() {
        return userName;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public String getUserContact() {
        return userContact;
    }

    public String getUserImage() {
        return userImage;
    }
}
