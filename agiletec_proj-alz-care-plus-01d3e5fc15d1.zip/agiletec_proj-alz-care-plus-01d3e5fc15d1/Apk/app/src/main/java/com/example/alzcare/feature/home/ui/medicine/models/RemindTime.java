package com.example.alzcare.feature.home.ui.medicine.models;

import com.google.gson.annotations.SerializedName;

public class RemindTime {
    @SerializedName("id")
    private String timeId;

    @SerializedName("time")
    private String reminderTime;

    public String getTimeId() {
        return timeId;
    }

    public void setTimeId(String timeId) {
        this.timeId = timeId;
    }

    public String getReminderTime() {
        return reminderTime;
    }

    public void setReminderTime(String reminderTime) {
        this.reminderTime = reminderTime;
    }
}
