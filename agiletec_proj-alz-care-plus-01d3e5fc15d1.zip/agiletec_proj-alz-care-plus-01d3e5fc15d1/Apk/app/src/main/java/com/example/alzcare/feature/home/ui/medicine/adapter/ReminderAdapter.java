package com.example.alzcare.feature.home.ui.medicine.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.alzcare.R;
import com.example.alzcare.common.utils.UiHandlers;
import com.example.alzcare.feature.home.ui.medicine.OnReminderActionListener;
import com.example.alzcare.feature.home.ui.medicine.models.ReminderModel;

import java.util.List;

public class ReminderAdapter extends RecyclerView.Adapter<ReminderAdapter.ViewHolder> {
    private final Context context;
    private List<ReminderModel> reminderList;

    OnReminderActionListener listener;

    public ReminderAdapter(Context context, List<ReminderModel> reminderList, OnReminderActionListener listener) {
        this.context = context;
        this.reminderList = reminderList;
        this.listener = listener;

    }

    @SuppressLint("NotifyDataSetChanged")
    public void setReminderList(List<ReminderModel> reminderList) {
        this.reminderList = reminderList;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ReminderAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.view_reminder, parent, false);
        return new ReminderAdapter.ViewHolder(view);
    }

    @SuppressLint({"SetTextI18n", "NotifyDataSetChanged"})
    @Override
    public void onBindViewHolder(@NonNull ReminderAdapter.ViewHolder holder, int position) {
        ReminderModel reminder = reminderList.get(position);
        holder.title.setText(reminder.getReminderTitle());
        holder.description.setText(reminder.getReminderDescription());
        holder.date.setText(reminder.getRemindFrom() + " - " + reminder.getRemindTo());
        StringBuilder times = new StringBuilder();
        for (int i = 0; i < reminder.getRemindTimes().size(); i++) {
            times.append(reminder.getRemindTimes().get(i).getReminderTime()).append(", ");
        }
        holder.time.setText(times.toString());

        holder.deleteReminder.setOnClickListener(v -> {
            UiHandlers.AlertDialog(context, "Delete Reminder", "Are you sure you want to delete this reminder?", (dialogInterface, i) -> {
                if (listener != null) {
                    listener.onReminderDelete(reminder.getReminderId());
                }
            });
        });
    }

    @Override
    public int getItemCount() {
        return reminderList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private final TextView title, description, date, time;
        private final ImageButton deleteReminder;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.tv_reminder_title);
            description = itemView.findViewById(R.id.tv_reminder_description);
            date = itemView.findViewById(R.id.tv_reminder_date_range);
            time = itemView.findViewById(R.id.tv_reminder_times);
            deleteReminder = itemView.findViewById(R.id.iv_reminder_options);
        }
    }


}
