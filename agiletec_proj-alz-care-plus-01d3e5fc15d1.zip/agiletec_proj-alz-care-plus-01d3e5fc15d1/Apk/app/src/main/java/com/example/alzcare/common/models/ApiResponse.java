package com.example.alzcare.common.models;

import androidx.annotation.Nullable;

public class ApiResponse<T> {
    private final boolean status;
    private final String message;
    @Nullable
    private final T data;

    public ApiResponse(boolean status, String message, @Nullable T data) {
        this.status = status;
        this.message = message;
        this.data = data;
    }

    public boolean isSuccess(){
        return status;
    }
    public String getMessage() {
        return message;
    }

    @Nullable
    public T getData() {
        return data;
    }
}
