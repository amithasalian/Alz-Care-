package com.example.alzcare.feature.home.ui.medicine;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.icu.text.SimpleDateFormat;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.Toolbar;
import androidx.core.util.Pair;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.FragmentManager;

import com.example.alzcare.R;
import com.example.alzcare.common.utils.UiHandlers;
import com.example.alzcare.feature.home.ui.medicine.models.AddReminderRequest;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.datepicker.CalendarConstraints;
import com.google.android.material.datepicker.DateValidatorPointForward;
import com.google.android.material.datepicker.MaterialDatePicker;
import com.google.android.material.datepicker.MaterialPickerOnPositiveButtonClickListener;
import com.google.android.material.textfield.TextInputLayout;
import com.google.android.material.timepicker.MaterialTimePicker;
import com.google.android.material.timepicker.TimeFormat;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class AddMedicineReminder extends DialogFragment {
    public static final String TAG = "medicine_remainder_dialog";
    private Toolbar toolbar;

    private EditText date, time, title, description;
    private Button submit;
    private int initialHour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
    private int initialMinute = Calendar.getInstance().get(Calendar.MINUTE);
    private LinearLayout layout;
    private String StartDate, EndDate = null;

    private String checkedText = "Once";
    private boolean is_valid = false;
    private final boolean is_success = false;
    private ProgressBar progressBar;
    private ChipGroup chipGroup;

    private final ReminderViewModel viewModel;

    private Map<String, String> time_data = new HashMap<>();
    private List<EditText> dynamicEditTextList = new ArrayList<>();


    public AddMedicineReminder(ReminderViewModel viewModel) {
        this.viewModel = viewModel;
    }

    public void display(FragmentManager fragmentManager) {
        AddMedicineReminder medicineReminder = new AddMedicineReminder(viewModel);
        medicineReminder.show(fragmentManager, AddMedicineReminder.TAG);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setStyle(DialogFragment.STYLE_NORMAL, R.style.Base_Theme_AlzCare);
    }

    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        View view = inflater.inflate(R.layout.fragment_add_reminder, container, false);
        toolbar = view.findViewById(R.id.toolbar);
        date = view.findViewById(R.id.appoint_remind_date);
        time = view.findViewById(R.id.appoint_remind_time);
        title = view.findViewById(R.id.appoint_remind_title);
        submit = view.findViewById(R.id.appoint_remind_submit);
        description = view.findViewById(R.id.appoint_remind_description);
        chipGroup = view.findViewById(R.id.chipGroup);
        layout = view.findViewById(R.id.time_container);
        progressBar = view.findViewById(R.id.progressBar);
        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        toolbar.setTitle("Add Remainder");
        toolbar.setNavigationOnClickListener(v -> dismiss());

        viewModel.getIsLoading().observe(getViewLifecycleOwner(), loading -> {
            if (loading) {
                UiHandlers.showProgress(progressBar, submit);
            } else {
                UiHandlers.hideProgress(progressBar, submit);
            }
        });

        viewModel.getDismissSheet().observe(getViewLifecycleOwner(), dismiss -> {
            if (dismiss) {
                dismiss();
                viewModel.resetDismissSheet();
            }
        });

        date.setOnClickListener(v -> showDatePicker());
        time.setOnClickListener(v -> showTimePicker(time, "time_1"));

        LayoutInflater inflater = getLayoutInflater();

        chipGroup.setOnCheckedChangeListener(new ChipGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(@NonNull ChipGroup group, int checkedId) {
                Chip checkedChip = group.findViewById(checkedId);
                if (checkedChip != null) {
                    checkedText = checkedChip.getText().toString();
                    int numberOfEditTexts = getNumberOfTimes(checkedText);
                    layout.removeAllViews();
                    dynamicEditTextList.clear();
                    for (int i = 0; i < numberOfEditTexts; i++) {
                        View view = inflater.inflate(R.layout.time_layout, layout, false);
                        int generatedId = View.generateViewId();
                        view.setId(generatedId);
                        layout.addView(view);
                        String id = "time_" + (i + 2);
                        TextInputLayout textInputLayout = (TextInputLayout) view;
                        EditText dynamicEditText = textInputLayout.findViewById(R.id.appoint_remind_time);
                        textInputLayout.setHint("Time " + (i + 2));
                        dynamicEditTextList.add(dynamicEditText);
                        dynamicEditText.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                showTimePicker(dynamicEditText, id);
                            }
                        });
                    }
                }
            }
        });

        submit.setOnClickListener(v -> {
            is_valid = validateRemainder();
            if (is_valid) {
                UiHandlers.AlertDialog(requireActivity(), "Alert!", "Are you sure you want to proceed?", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        AddReminderRequest request = new AddReminderRequest(
                                StartDate,
                                EndDate,
                                title.getText().toString(),
                                description.getText().toString(),
                                new ArrayList<>(time_data.values())
                        );
                        viewModel.addReminder(request);
                    }
                });
            }
        });

    }

    private int getNumberOfTimes(String checkedText) {
        switch (checkedText) {
            case "Twice":
                return 1;
            case "Thrice":
                return 2;
            default:
                return 0; // Default to one TextInputEditText
        }
    }

    private boolean validateRemainder() {
        if (title.length() == 0) {
            UiHandlers.shortToast(getContext(), "Tablet name is required");
            return false;
        }
        if (description.length() == 0) {
            UiHandlers.shortToast(getContext(), "Description is required");
            return false;
        }
        if (date.length() == 0) {
            UiHandlers.shortToast(getContext(), "Please select the date");
            return false;
        }
        if (time.length() == 0) {
            UiHandlers.shortToast(getContext(), "Please select the time");
            return false;
        }
        for (EditText dynamicEdit : dynamicEditTextList) {
            if (dynamicEdit.length() == 0) {
                UiHandlers.shortToast(getContext(), "Please select the " + dynamicEdit.getHint());
                return false;
            }
        }
        return true;
    }


    private void showTimePicker(EditText dynamicEditText, String id) {
        MaterialTimePicker timePicker = new MaterialTimePicker.Builder()
                .setTimeFormat(TimeFormat.CLOCK_24H)
                .setHour(initialHour)
                .setMinute(initialMinute)
                .setInputMode(MaterialTimePicker.INPUT_MODE_CLOCK) // Use INPUT_MODE_CLOCK for the clock style
                .build();

        timePicker.addOnPositiveButtonClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int hour = timePicker.getHour();
                int minute = timePicker.getMinute();
                initialHour = timePicker.getHour();
                initialMinute = timePicker.getMinute();
                // Handle the valid selected time
                @SuppressLint("DefaultLocale") String formattedTime = String.format("%02d:%02d", hour, minute);
                dynamicEditText.setText(formattedTime);
                time_data.put(id, formattedTime);
            }
        });
        timePicker.show(getChildFragmentManager(), TAG);
    }

    private void showDatePicker() {
        long today = MaterialDatePicker.todayInUtcMilliseconds();

        CalendarConstraints.Builder constraintsBuilder = new CalendarConstraints.Builder();
        constraintsBuilder.setStart(today);
        constraintsBuilder.setValidator(DateValidatorPointForward.now());

        MaterialDatePicker<Pair<Long, Long>> datePicker = MaterialDatePicker.Builder.dateRangePicker()
                .setTitleText("Select Date")
                .setSelection(Pair.create(today, today))
                .setCalendarConstraints(constraintsBuilder.build())  // Apply constraints
                .build();

        datePicker.addOnPositiveButtonClickListener(new MaterialPickerOnPositiveButtonClickListener<Pair<Long, Long>>() {
            @Override
            public void onPositiveButtonClick(Pair<Long, Long> selection) {
                long startDate = selection.first;
                long endDate = selection.second;

                // Convert the selected dates to Calendar objects
                Calendar startCalendar = Calendar.getInstance();
                startCalendar.setTimeInMillis(startDate);

                Calendar endCalendar = Calendar.getInstance();
                endCalendar.setTimeInMillis(endDate);

                SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
                StartDate = dateFormat.format(startCalendar.getTime());
                EndDate = dateFormat.format(endCalendar.getTime());
                String result = StartDate.concat(" to ").concat(EndDate);
                date.setText(result);
            }
        });

        datePicker.show(getChildFragmentManager(), TAG);
    }
}
