package com.example.alzcare;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.example.alzcare.common.utils.SharedPref;
import com.example.alzcare.feature.auth.LoginActivity;
import com.example.alzcare.feature.home.HomeActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        Intent intent;
        boolean isAuthenticated = SharedPref.getIsAuthenticated(this);
        if (isAuthenticated) {
            intent = new Intent(this, HomeActivity.class);
        } else {
            intent = new Intent(this, LoginActivity.class);
        }
        new Handler().postDelayed(() ->
        {
            startActivity(intent);
            finish();
        }, 2500);
    }
}