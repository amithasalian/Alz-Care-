package com.example.alzcare.feature.home.ui.medicine;

public interface OnReminderActionListener {
    void onReminderDelete(String reminderId);
}
