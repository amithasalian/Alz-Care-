package com.example.alzcare.feature.auth;

import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ProgressBar;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.example.alzcare.R;
import com.example.alzcare.common.models.ApiResponse;
import com.example.alzcare.common.utils.UiHandlers;
import com.example.alzcare.feature.auth.models.RegisterRequest;
import com.example.alzcare.network.handlers.RequestHandler;
import com.example.alzcare.network.handlers.ResponseListener;

public class RegisterActivity extends AppCompatActivity implements View.OnClickListener {
    private Button Register;
    private ProgressBar progressBar;
    private EditText Name, Contact, Email, Password;
    private RequestHandler requestHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_register);

        requestHandler = new RequestHandler();

        Register = findViewById(R.id.user_register);
        Name = findViewById(R.id.user_name);
        Contact = findViewById(R.id.user_phone);
        Email = findViewById(R.id.user_email);
        Password = findViewById(R.id.user_password);

        Button signIN = findViewById(R.id.login_now);
        ImageButton backButton = findViewById(R.id.backButton);

        progressBar = findViewById(R.id.progressBar);

        Register.setOnClickListener(this);
        signIN.setOnClickListener(this);
        backButton.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.login_now || v.getId() == R.id.backButton) {
            getOnBackPressedDispatcher().onBackPressed();
        } else if (v.getId() == R.id.user_register) {
            if (validateUser()) {
                createUser();
            }
        }
    }

    private void createUser() {
        UiHandlers.showProgress(progressBar, Register);
        RegisterRequest request = new RegisterRequest(
                Name.getText().toString(),
                Contact.getText().toString(),
                Email.getText().toString(),
                Password.getText().toString()
        );

        requestHandler.registerUser(request, new ResponseListener<ApiResponse<Void>>() {
            @Override
            public void onSuccess(ApiResponse<Void> response) {
                UiHandlers.hideProgress(progressBar, Register);
                UiHandlers.shortToast(getApplicationContext(), response.getMessage());
                if (response.isSuccess()) {
                    finish();
                }
            }

            @Override
            public void onFailure(String errorMessage) {
                UiHandlers.hideProgress(progressBar, Register);
                UiHandlers.shortToast(getApplicationContext(), errorMessage);
            }
        });
    }

    private boolean validateUser() {
        if (Name.length() == 0) {
            UiHandlers.shortToast(getApplicationContext(), "Name Field is required");
            return false;
        }
        if (Contact.length() == 0) {
            UiHandlers.shortToast(getApplicationContext(), "Phone number is required");
            return false;
        }
        if (!Patterns.PHONE.matcher(Contact.getText().toString()).matches() || Contact.length() < 10) {
            UiHandlers.shortToast(getApplicationContext(), "Invalid phone number");
            return false;
        }
        if (Email.length() == 0) {
            UiHandlers.shortToast(getApplicationContext(), "Email id is required");
            return false;
        }
        if (!Patterns.EMAIL_ADDRESS.matcher(Email.getText().toString()).matches()) {
            UiHandlers.shortToast(getApplicationContext(), "Invalid email id");
            return false;
        }
        if (Password.length() == 0) {
            UiHandlers.shortToast(getApplicationContext(), "Password is required");
            return false;
        }
        return true;
    }
}