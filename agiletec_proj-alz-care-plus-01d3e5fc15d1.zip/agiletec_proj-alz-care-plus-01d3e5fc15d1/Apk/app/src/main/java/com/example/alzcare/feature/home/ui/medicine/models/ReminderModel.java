package com.example.alzcare.feature.home.ui.medicine.models;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class ReminderModel {
    @SerializedName("id")
    private String reminderId;

    @SerializedName("title")
    private String reminderTitle;

    @SerializedName("description")
    private String reminderDescription;

    @SerializedName("from_date")
    private String remindFrom;

    @SerializedName("to_date")
    private String remindTo;

    @SerializedName("reminder_time")
    private List<RemindTime> remindTimes;

    public String getReminderId() {
        return reminderId;
    }

    public void setReminderId(String reminderId) {
        this.reminderId = reminderId;
    }

    public String getReminderTitle() {
        return reminderTitle;
    }

    public void setReminderTitle(String reminderTitle) {
        this.reminderTitle = reminderTitle;
    }

    public String getReminderDescription() {
        return reminderDescription;
    }

    public void setReminderDescription(String reminderDescription) {
        this.reminderDescription = reminderDescription;
    }

    public String getRemindFrom() {
        return remindFrom;
    }

    public void setRemindFrom(String remindFrom) {
        this.remindFrom = remindFrom;
    }

    public String getRemindTo() {
        return remindTo;
    }

    public void setRemindTo(String remindTo) {
        this.remindTo = remindTo;
    }

    public List<RemindTime> getRemindTimes() {
        return remindTimes;
    }

    public void setRemindTimes(List<RemindTime> remindTimes) {
        this.remindTimes = remindTimes;
    }
}
