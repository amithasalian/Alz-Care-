package com.example.alzcare.network;

import com.example.alzcare.common.models.ApiResponse;
import com.example.alzcare.common.models.UserSession;
import com.example.alzcare.feature.auth.models.LoginRequest;
import com.example.alzcare.feature.auth.models.RegisterRequest;
import com.example.alzcare.feature.auth.models.SendOtpRequest;
import com.example.alzcare.feature.auth.models.VerifyOtpRequest;
import com.example.alzcare.feature.home.ui.home.models.PredictResult;
import com.example.alzcare.feature.home.ui.medicine.models.AddReminderRequest;
import com.example.alzcare.feature.home.ui.medicine.models.ReminderModel;
import com.example.alzcare.feature.home.ui.user.models.UserModel;

import java.util.List;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Query;

public interface ApiService {
    @POST("auth/login/")
    Call<ApiResponse<UserSession>> loginUser(@Body LoginRequest loginRequest);

    @POST("auth/register/")
    Call<ApiResponse<Void>> registerUser(@Body RegisterRequest registerRequest);

    @POST("auth/send-otp/")
    Call<ApiResponse<String>> sendOtp(@Body SendOtpRequest otpRequest);

    @POST("auth/verify-otp/")
    Call<ApiResponse<Void>> verifyOtp(@Body VerifyOtpRequest verifyOtpRequest);

    @GET("user/")
    Call<ApiResponse<UserModel>> getUser(@Query("user") String user);

    @Multipart
    @POST("user/")
    Call<ApiResponse<UserModel>> updateUser(
            @Part("user") RequestBody user,
            @Part MultipartBody.Part image
    );

    @POST("reminder/")
    Call<ApiResponse<ReminderModel>> addReminder(@Body AddReminderRequest request);

    @GET("reminder/")
    Call<ApiResponse<List<ReminderModel>>> getReminder(@Query("user") String user);

    @DELETE("reminder/")
    Call<ApiResponse<Void>> deleteReminder(@Query("reminder") String reminderId);

    @Multipart
    @POST("predict/")
    Call<ApiResponse<PredictResult>> predictDisease(
            @Part("user") RequestBody user,
            @Part MultipartBody.Part image
    );


}
