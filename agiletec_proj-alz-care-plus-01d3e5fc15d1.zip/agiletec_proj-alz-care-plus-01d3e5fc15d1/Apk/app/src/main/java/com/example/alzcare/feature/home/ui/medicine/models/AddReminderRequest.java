package com.example.alzcare.feature.home.ui.medicine.models;

import java.util.List;
import java.util.Map;

public class AddReminderRequest {
    private final String from_date, to_date, title, description;
    private final List<String> times;
    private String user;

    public AddReminderRequest(String fromDate, String toDate, String title, String description, List<String> times) {
        this.from_date = fromDate;
        this.to_date = toDate;
        this.title = title;
        this.description = description;
        this.times = times;
    }

    public String getFrom_date() {
        return from_date;
    }

    public String getTo_date() {
        return to_date;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public List<String> getTimes() {
        return times;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }
}
