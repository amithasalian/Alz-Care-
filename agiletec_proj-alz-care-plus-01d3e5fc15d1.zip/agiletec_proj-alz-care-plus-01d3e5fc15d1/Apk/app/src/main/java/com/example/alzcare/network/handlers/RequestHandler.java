package com.example.alzcare.network.handlers;

import com.example.alzcare.common.models.ApiResponse;
import com.example.alzcare.common.models.UserSession;
import com.example.alzcare.feature.auth.models.LoginRequest;
import com.example.alzcare.feature.auth.models.RegisterRequest;
import com.example.alzcare.feature.auth.models.SendOtpRequest;
import com.example.alzcare.feature.auth.models.VerifyOtpRequest;
import com.example.alzcare.feature.home.ui.home.models.PredictResult;
import com.example.alzcare.feature.home.ui.medicine.models.AddReminderRequest;
import com.example.alzcare.feature.home.ui.medicine.models.ReminderModel;
import com.example.alzcare.feature.home.ui.user.models.UserModel;

import java.util.List;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;

public class RequestHandler extends BaseRequestHandler {
    public void registerUser(RegisterRequest registerRequest, ResponseListener<ApiResponse<Void>> listener) {
        Call<ApiResponse<Void>> call = apiService.registerUser(registerRequest);
        enqueueCall(call, listener);
    }

    public void loginUser(LoginRequest loginRequest, ResponseListener<ApiResponse<UserSession>> listener) {
        Call<ApiResponse<UserSession>> call = apiService.loginUser(loginRequest);
        enqueueCall(call, listener);
    }

    public void sendOtp(SendOtpRequest otpRequest, ResponseListener<ApiResponse<String>> listener) {
        Call<ApiResponse<String>> call = apiService.sendOtp(otpRequest);
        enqueueCall(call, listener);
    }

    public void verifyOtp(VerifyOtpRequest verifyOtpRequest, ResponseListener<ApiResponse<Void>> listener) {
        Call<ApiResponse<Void>> call = apiService.verifyOtp(verifyOtpRequest);
        enqueueCall(call, listener);
    }

    public void getUserData(String user, ResponseListener<ApiResponse<UserModel>> listener) {
        Call<ApiResponse<UserModel>> call = apiService.getUser(user);
        enqueueCall(call, listener);
    }

    public void updateUser(RequestBody user, MultipartBody.Part image, ResponseListener<ApiResponse<UserModel>> listener) {
        Call<ApiResponse<UserModel>> call = apiService.updateUser(user, image);
        enqueueCall(call, listener);
    }

    public void addMedicineReminder(AddReminderRequest request, ResponseListener<ApiResponse<ReminderModel>> listener) {
        Call<ApiResponse<ReminderModel>> call = apiService.addReminder(request);
        enqueueCall(call, listener);
    }

    public void getMedicineReminders(String user, ResponseListener<ApiResponse<List<ReminderModel>>> listener) {
        Call<ApiResponse<List<ReminderModel>>> call = apiService.getReminder(user);
        enqueueCall(call, listener);
    }

    public void deleteReminder(String reminderId, ResponseListener<ApiResponse<Void>> listener) {
        Call<ApiResponse<Void>> call = apiService.deleteReminder(reminderId);
        enqueueCall(call, listener);
    }

    public void predictDisease(MultipartBody.Part image, RequestBody userId, ResponseListener<ApiResponse<PredictResult>> listener) {
        Call<ApiResponse<PredictResult>> call = apiService.predictDisease(userId, image);
        enqueueCall(call, listener);
    }
}
