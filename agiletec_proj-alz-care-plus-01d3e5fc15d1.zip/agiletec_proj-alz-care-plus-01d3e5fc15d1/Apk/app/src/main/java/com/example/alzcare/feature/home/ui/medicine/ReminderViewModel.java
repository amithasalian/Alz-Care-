package com.example.alzcare.feature.home.ui.medicine;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.alzcare.common.models.ApiResponse;
import com.example.alzcare.common.models.UserSession;
import com.example.alzcare.common.utils.SharedPref;
import com.example.alzcare.common.utils.UiHandlers;
import com.example.alzcare.feature.home.ui.medicine.models.AddReminderRequest;
import com.example.alzcare.feature.home.ui.medicine.models.ReminderModel;
import com.example.alzcare.network.handlers.RequestHandler;
import com.example.alzcare.network.handlers.ResponseListener;

import java.util.List;

public class ReminderViewModel extends AndroidViewModel {
    private final MutableLiveData<Boolean> isLoading = new MutableLiveData<>(false); // Progress state
    private final MutableLiveData<Boolean> dismissSheet = new MutableLiveData<>(false); // Progress state
    private final MutableLiveData<List<ReminderModel>> reminders = new MutableLiveData<>();
    private final MutableLiveData<Boolean> progressLoading = new MutableLiveData<>(false); // Progress state

    private final RequestHandler requestHandler;
    private final UserSession userSession;

    public ReminderViewModel(@NonNull Application application) {
        super(application);
        this.requestHandler = new RequestHandler();
        this.userSession = SharedPref.getUserSession(application);
    }

    public LiveData<Boolean> getIsLoading() {
        return isLoading;
    }

    public LiveData<Boolean> getProgressLoading() {
        return progressLoading;
    }

    public LiveData<Boolean> getDismissSheet() {
        return dismissSheet;
    }

    public void resetDismissSheet() {
        dismissSheet.setValue(false);
    }

    public LiveData<List<ReminderModel>> getReminders() {
        return reminders;
    }

    public void addReminder(AddReminderRequest request) {
        isLoading.setValue(true);
        request.setUser(userSession.getId());
        requestHandler.addMedicineReminder(request, new ResponseListener<ApiResponse<ReminderModel>>() {
            @Override
            public void onSuccess(ApiResponse<ReminderModel> response) {
                isLoading.setValue(false);
                getMedicineReminders();
                dismissSheet.setValue(true);
                UiHandlers.shortToast(getApplication(), "Reminder added successfully");
            }

            @Override
            public void onFailure(String errorMessage) {
                UiHandlers.shortToast(getApplication(), errorMessage);
                isLoading.setValue(false);
            }
        });
    }

    public void getMedicineReminders() {
        progressLoading.setValue(true);
        requestHandler.getMedicineReminders(userSession.getId(), new ResponseListener<ApiResponse<List<ReminderModel>>>() {
            @Override
            public void onSuccess(ApiResponse<List<ReminderModel>> response) {
                progressLoading.setValue(false);
                if (response.getData() != null) {
                    reminders.setValue(response.getData());
                }
            }

            @Override
            public void onFailure(String errorMessage) {
                UiHandlers.shortToast(getApplication(), errorMessage);
                progressLoading.setValue(false);
            }
        });
    }

    public void deleteReminder(String reminderId) {
        requestHandler.deleteReminder(reminderId, new ResponseListener<ApiResponse<Void>>() {
            @Override
            public void onSuccess(ApiResponse<Void> response) {
                getMedicineReminders();
            }

            @Override
            public void onFailure(String errorMessage) {
                UiHandlers.shortToast(getApplication(), errorMessage);
            }
        });
    }
}
