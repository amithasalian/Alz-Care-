package com.example.alzcare.common.utils;


import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.Settings;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.example.alzcare.R;

import java.io.File;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;

public class Utils {
    @SuppressLint("HardwareIds")
    public static String getDeviceId(Context context) {
        return Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
    }

    public static void loadImage(Context context, String imagePath, ImageView imageView) {
        Glide.with(context).load(imagePath).error(R.drawable.app_logo).into(imageView);
    }

    public static RequestBody toRequestBody(String value) {
        return RequestBody.create(MediaType.parse("text/plain"), value);
    }

    public static MultipartBody.Part toImagePart(String title, Bitmap bitmap, Context context) {
        File imageFile = FileUtils.bitmapToFile(bitmap, context);
        String filePath = FileUtils.getRealPathFromUri(context, Uri.fromFile(imageFile));
        File file = new File(filePath);
        RequestBody requestFile = RequestBody.create(MediaType.parse("multipart/form-data"), file);
        return MultipartBody.Part.createFormData(title, file.getName(), requestFile);
    }
}
