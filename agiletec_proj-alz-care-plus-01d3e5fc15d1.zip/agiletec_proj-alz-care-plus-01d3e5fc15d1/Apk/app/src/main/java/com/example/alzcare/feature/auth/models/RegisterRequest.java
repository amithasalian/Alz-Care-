package com.example.alzcare.feature.auth.models;

public class RegisterRequest {
    private final String name, contact, email, password;

    public RegisterRequest(String name, String contact, String email, String password) {
        this.name = name;
        this.contact = contact;
        this.email = email;
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public String getContact() {
        return contact;
    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }
}
