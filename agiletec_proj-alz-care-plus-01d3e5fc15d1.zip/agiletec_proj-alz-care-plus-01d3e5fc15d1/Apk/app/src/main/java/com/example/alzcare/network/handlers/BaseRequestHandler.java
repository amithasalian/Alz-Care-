package com.example.alzcare.network.handlers;

import android.util.Log;

import androidx.annotation.NonNull;

import com.example.alzcare.common.models.ApiResponse;
import com.example.alzcare.network.ApiClient;
import com.example.alzcare.network.ApiService;

import org.json.JSONObject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class BaseRequestHandler {
    protected final ApiService apiService;

    protected BaseRequestHandler() {
        this.apiService = ApiClient.getInstance().getApiService();
    }

    protected <T> void enqueueCall(Call<ApiResponse<T>> call, final ResponseListener<ApiResponse<T>> responseListener) {
        call.enqueue(new Callback<ApiResponse<T>>() {
            @Override
            public void onResponse(@NonNull Call<ApiResponse<T>> call, @NonNull Response<ApiResponse<T>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    responseListener.onSuccess(response.body());
                } else {
                    try {
                        if (response.errorBody() != null) {
                            String errorJson = response.errorBody().string(); // Convert to string
                            JSONObject jsonObject = new JSONObject(errorJson); // Convert to JSON
                            String errorMessage = jsonObject.optString("message", "Unknown error"); // Get "message" field safely
                            Log.e("API_ERROR", "Response error: " + errorMessage);
                            responseListener.onFailure(errorMessage);
                        } else {
                            responseListener.onFailure("Unknown error");
                        }
                    } catch (Exception e) {
                        Log.e("API_ERROR", "Error parsing response", e);
                        responseListener.onFailure("Unknown error occurred...");
                    }

                }
            }

            @Override
            public void onFailure(@NonNull Call<ApiResponse<T>> call, @NonNull Throwable t) {
                responseListener.onFailure(t.getMessage());

            }
        });
    }
}
