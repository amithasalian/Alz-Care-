package com.example.alzcare.feature.home.ui.user;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;

import com.example.alzcare.R;
import com.example.alzcare.common.models.ApiResponse;
import com.example.alzcare.common.models.UserSession;
import com.example.alzcare.common.utils.MediaUtils;
import com.example.alzcare.common.utils.PermissionUtils;
import com.example.alzcare.common.utils.SharedPref;
import com.example.alzcare.common.utils.UiHandlers;
import com.example.alzcare.common.utils.Utils;
import com.example.alzcare.feature.auth.LoginActivity;
import com.example.alzcare.feature.home.ui.user.models.UserModel;
import com.example.alzcare.network.handlers.RequestHandler;
import com.example.alzcare.network.handlers.ResponseListener;
import com.google.android.material.imageview.ShapeableImageView;

import java.io.IOException;
import java.io.InputStream;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;

public class UserFragment extends Fragment {

    private Button logout, changeProfile, changePassword;
    private RequestHandler requestHandler;
    private UserSession userSession;
    private ShapeableImageView userImage;
    private TextView userName, userEmail, userContact, userGender, userAddress;
    private Bitmap imageBitmap;
    private MediaUtils mediaUtils;
    private ProgressBar progressBar;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_user, container, false);
    }

    @RequiresApi(api = Build.VERSION_CODES.TIRAMISU)
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        requestHandler = new RequestHandler();
        mediaUtils = new MediaUtils(requireActivity());
        userSession = SharedPref.getUserSession(getContext());

        userName = view.findViewById(R.id.user_name);
        userEmail = view.findViewById(R.id.user_email);
        userImage = view.findViewById(R.id.profile_image);
        userContact = view.findViewById(R.id.user_contact);
        progressBar = view.findViewById(R.id.profile_loading_progress);

        logout = view.findViewById(R.id.logout_button);
        changeProfile = view.findViewById(R.id.change_picture_button);

        logout.setOnClickListener(v -> {
            UiHandlers.AlertDialog(getContext(), "Logout", "Are you sure you want to logout?", ((dialog, which) -> {
                performLogout();
            }));
        });

        changeProfile.setOnClickListener(v -> changeImage());
        getUserData(userSession.getId());
    }

    @RequiresApi(api = Build.VERSION_CODES.TIRAMISU)
    private void changeImage() {
        if (!PermissionUtils.hasPermissions(requireContext())) {
            PermissionUtils.requestPermissions(getActivity());
        } else {
            mediaUtils.showMediaDialog(mediaLauncher);
        }
    }

    private void getUserData(String id) {
        requestHandler.getUserData(id, new ResponseListener<ApiResponse<UserModel>>() {
            @Override
            public void onSuccess(ApiResponse<UserModel> response) {
                if (response.isSuccess()) {
                    assert response.getData() != null;
                    setUser(response.getData());
                }
            }

            @Override
            public void onFailure(String errorMessage) {
                UiHandlers.shortToast(getContext(), errorMessage);
            }
        });
    }

    private void setUser(UserModel data) {
        userName.setText(data.getUserName());
        userEmail.setText(data.getUserEmail());
        userContact.setText(data.getUserContact());
        Utils.loadImage(getContext(), data.getUserImage(), userImage);
    }

    private void performLogout() {
        SharedPref.clearAllPreferences(requireContext());
        UiHandlers.shortToast(requireContext(), "Logout Successfully...");
        Intent intent = new Intent(requireContext(), LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
    }

    private final ActivityResultLauncher<Intent> mediaLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == Activity.RESULT_OK) {
                    Intent data = result.getData();
                    imageBitmap = null;

                    if (data != null && data.getData() != null) {
                        // Image selection from gallery
                        try {
                            InputStream inputStream = requireActivity().getContentResolver().openInputStream(data.getData());
                            imageBitmap = BitmapFactory.decodeStream(inputStream);
                            assert inputStream != null;
                            inputStream.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }

                    } else if (data != null && data.getExtras() != null && data.getExtras().get("data") != null) {
                        // capture image
                        imageBitmap = (Bitmap) data.getExtras().get("data");
                    }
                    updateUser(imageBitmap);
                }
            }
    );

    private void updateUser(Bitmap imageBitmap) {
        if (imageBitmap == null) {
            UiHandlers.shortToast(getContext(), "No image selected");
            return;
        }
        progressBar.setVisibility(View.VISIBLE);
        MultipartBody.Part imagePart = Utils.toImagePart("image", imageBitmap, getActivity());
        RequestBody userPart = Utils.toRequestBody(userSession.getId());
        requestHandler.updateUser(userPart, imagePart, new ResponseListener<ApiResponse<UserModel>>() {
            @Override
            public void onSuccess(ApiResponse<UserModel> response) {
                progressBar.setVisibility(View.GONE);
                UiHandlers.shortToast(getContext(), "Profile updated successfully");
                assert response.getData() != null;
                setUser(response.getData());
            }

            @Override
            public void onFailure(String errorMessage) {
                progressBar.setVisibility(View.GONE);
                UiHandlers.shortToast(getContext(), errorMessage);
            }
        });

    }
}