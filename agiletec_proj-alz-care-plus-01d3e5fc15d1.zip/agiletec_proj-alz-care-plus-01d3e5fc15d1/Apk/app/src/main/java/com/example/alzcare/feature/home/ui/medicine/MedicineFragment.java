package com.example.alzcare.feature.home.ui.medicine;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.alzcare.R;
import com.example.alzcare.feature.home.ui.medicine.adapter.ReminderAdapter;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class MedicineFragment extends Fragment implements OnReminderActionListener {

    private ReminderAdapter adapter;
    private ProgressBar progressBar;
    private ReminderViewModel viewModel;
    private View notFoundView = null;
    private RelativeLayout mainLayout;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_medicine, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        FloatingActionButton addRemainder = view.findViewById(R.id.add_medicine_remainder);
        RecyclerView recyclerView = view.findViewById(R.id.recyclerView);
        mainLayout = view.findViewById(R.id.main);
        progressBar = view.findViewById(R.id.progressBar);

        addRemainder.setOnClickListener(view1 -> {
            AddMedicineReminder addMedicineReminder = new AddMedicineReminder(viewModel);
            addMedicineReminder.display(getChildFragmentManager());
        });

        viewModel = new ViewModelProvider(requireActivity()).get(ReminderViewModel.class);

        LinearLayoutManager layoutManager = new LinearLayoutManager(requireContext());
        recyclerView.setLayoutManager(layoutManager);
        adapter = new ReminderAdapter(requireContext(), new ArrayList<>(), this);
        recyclerView.setAdapter(adapter);

        viewModel.getMedicineReminders();

        viewModel.getReminders().observe(getViewLifecycleOwner(), reminders -> {
            adapter.setReminderList(reminders);

            boolean isEmpty = reminders == null || reminders.isEmpty();

            if (isEmpty) {
                if (notFoundView == null) {
                    notFoundView = getLayoutInflater().inflate(R.layout.view_not_found, null);
                    mainLayout.addView(notFoundView);
                }
            } else {
                if (notFoundView != null) {
                    mainLayout.removeView(notFoundView);
                    notFoundView = null;
                }
            }
        });

        viewModel.getProgressLoading().observe(getViewLifecycleOwner(), loading -> {
            if (loading) {
                progressBar.setVisibility(View.VISIBLE);
            } else {
                progressBar.setVisibility(View.GONE);
            }
        });
    }

    @SuppressLint("NotifyDataSetChanged")
    @Override
    public void onReminderDelete(String reminderId) {
        viewModel.deleteReminder(reminderId);
    }
}